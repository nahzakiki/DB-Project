<meta charset="UTF-8">
<?php
include('server.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
//รับค่าไฟล์จากฟอร์ม
//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');
//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
$date1 = date("Ymd_His");

$qty = "select Product_No from Products";
$result2 = $conn->query($qty);
$Product_No = "";
while ($row = mysqli_fetch_array($result2)) {
	$Product_No = $row['Product_No'];
}
$Product_No = ((int)$Product_No) + 1;
$Product_Name = $_POST['Product_Name'];
$Product_type = $_POST['type_id'];
$Product_Price = $_POST['Product_Price'];
$Product_Stock = $_POST['Product_Stock'];
$p_img = (isset($_POST['Product_img']) ? $_POST['Product_img'] : '');
//img
$upload = $_FILES['Product_img'];
if ($upload <> '') {

	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname =  $_FILES['Product_img']['name'];
	$path_copy = $newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['Product_img']['tmp_name'], $path_copy);
	
}

//echo $Product_No.'<br>'.$Product_Name.'<br>'.$Product_type.'<br>'.$Product_Price.'<br>'.$Product_Stock.'<br>'.$newname;
// เพิ่มไฟล์เข้าไปในตาราง uploadfile

$sql = "INSERT INTO Products
		(
        Product_No,
		Product_Name,
		Product_Price,
        Product_Stock,
		Product_img,
		Product_type
		)
		VALUES
		(
		'$Product_No',
        '$Product_Name',
		'$Product_Price',
        '$Product_Stock',
		'$newname',
		'$Product_type')";

$result = mysqli_query($conn, $sql); // or die ("Error in query: $sql " . mysqli_error());

mysqli_close($conn);
// javascript แสดงการ upload file


if ($result) {
	echo "<script type='text/javascript'>";
	echo "alert('Add Succesfuly');";
	echo "window.location = 'product.php'; ";
	echo "</script>";
} else {
	echo "<script type='text/javascript'>";
	echo "alert('Error back to upload again');";
	echo "window.location = 'product.php'; ";
	echo "</script>";
}
?>