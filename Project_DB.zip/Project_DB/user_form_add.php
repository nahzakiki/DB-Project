<?php include('h.php'); ?>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMART SHOP</title>

  <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="css/bootstrap-grid.min.css">
</head>
<div class="container">
  <p> </p>
  <div class="row">
    <div class="col-md-12">
      <center>
        <form name="admin" action="user_form_add_db.php" method="POST" id="admin" class="form-horizontal">
          <div class="form-group">
            <div class="col-sm-6" align="left">
                <p>Username</p>
              <input name="username" type="text" required class="form-control" id="username" placeholder="Username"  minlength="2" />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-6" align="left">
            <p>Email</p>
              <input name="email" type="text" required class="form-control" id="Email" placeholder="Email"  minlength="2" />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-6" align="left">
            <p>Password</p>
              <input name="password" type="text" required class="form-control" id="password" placeholder="Password"  minlength="2" />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-6" align="right">
              <button type="submit" class="btn btn-success btn-sm" id="btn"> submit </button>
            </div>
          </div>
        </form>
      </center>
    </div>
  </div>
</div>