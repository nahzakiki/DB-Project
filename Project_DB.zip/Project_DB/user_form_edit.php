<?php
//1. เชื่อมต่อ database:
include('server.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
$username = $_REQUEST["ID"];
//2. query ข้อมูลจากตาราง:
$sql = "SELECT * FROM user WHERE username='$username' ";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);
extract($row);
?>
<?php include('h.php'); ?>
<div class="container">
    <p> </p>
    <div class="row">
        <div class="col-md-12">
            <form name="admin" action="user_form_edit_db.php" method="POST" id="admin" class="form-horizontal">
                <input type="hidden" name="username" value="<?php echo $username; ?>" />
                <div class="form-group">
                    <div class="col-sm-6 col-md-12" align="left">
                        <p>Username</p>
                        <input name="username" type="text" required class="form-control" value="<?php echo $username; ?>" id="username"
                            placeholder="Username" minlength="2" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12 col-md-12" align="left">
                        <p>Email</p>
                        <input name="email" type="text" required class="form-control" id="Email" value="<?php echo $row['email']; ?>" placeholder="Email"
                            minlength="2" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12 col-md-12" align="left">
                        <p>Password</p>
                        <input name="password" type="text" required class="form-control" id="password"
                            placeholder="Password" minlength="2" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12 col-md-12" align="right">
                        <button type="submit" class="btn btn-success btn-sm" id="btn"> summit </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>