<?php 
    include('server.php');
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART SHOP</title>
    <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
</head>
<style>
    body{
        background-color: rgb(240, 123, 123);
    }
    .button {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }
    
    .button {
        background-color: #555555;
        /* Green */
        border: none;
        color: white;
        padding: 16px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }
    
    .button:hover {
        background-color: white;
        color: #555555;
    }
    
    .button {
        border-radius: 12px;
    }
</style>
<body> 
    <CENTER>
        <div>
            <img src="LOGO1_frame.png" align="center">
        </div>
        <a class="button" href="page2.php">เข้าสู่เว็บไซต์</a>
    </CENTER>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>