<?php
include('server.php');
session_start();

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header('location: page2.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART SHOP</title>

    <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
</head>
<style>
    body {
        background-color: white;
    }

    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: rgb(240, 123, 123);
    }

    li {
        float: left;
    }

    li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-family: 'Segoe UI';
        font-size: 90%;
    }


    li a:hover {
        background-color: burlywood;
    }

    h1 {
        font-size: 18px;
    }

    p {
        font-size: 16px;
    }

    div.card {
        margin: 10px;
    }

    .btn-btn-primary {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .btn-btn-primary {
        background-color: rgb(176, 255, 0);
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .btn-btn-primary:hover {
        background-color: white;
        color: rgb(176, 255, 0);
    }

    .btn-btn-primary {
        border-radius: 12px;
    }

    .input {
        width: 300px;
        height: 50px;
        padding: 10px 10px;
    }

    .search-s {
        width: 250px;
        height: 20px;
        padding: 10px 10px;
        border-radius: 20px;
        border-color: rgb(240, 123, 123);
    }

    .button {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .button {
        background-color: #FFF4C0;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .button:hover {
        background-color: white;
        color: #FFF4C0;
    }

    .button {
        border-radius: 12px;
    }
</style>
<body>
    <ul>
        <div class="container">
            <div class="row align-items-start">

                <div class="col">
                    <li>
                        <a class="active" href="product.php"><img src="LOGO_SM.png" width="80"></a>
                    </li>
                    <li style="float: right;">
                        <?php if (isset($_SESSION['username'])) : ?>
                            <p>User : <strong><?php echo $_SESSION['username']; ?></strong></p>
                            <a class="btn-btn-primary" href="page2.php" style="color: red;">Logout</a>
                        <?php endif ?>
                    </li>
                    <li>
                        <div class="col-md-3">
                            <?php include('menu_left.php'); ?>
                        </div>
                    </li>

                </div>
            </div>
        </div>
    </ul>

    <head>
        <?php
        include('h.php');
        error_reporting(error_reporting() & ~E_NOTICE);
        ?>

        <head>

        <body>
            <div class="container">
                <p></p>
                <div class="row">
                    <div class="col-md-6"></div>
                    <a href="product.php?act=add" class="btn-info btn-sm">add</a>
                    <p></p>

                    <?php
                    $act = isset($_GET['act']) ? $_GET['act'] : '';
                    if ($act == 'add') {
                        include('product_form_add.php');
                    } elseif ($act == 'edit') {
                        include('product_form_edit.php');
                    } else {
                        include('product_list.php');
                    }
                    ?>
                </div>
            </div>
        </body>
    </head>
</body>

</html>