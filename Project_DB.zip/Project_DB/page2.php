<?php 
include('server.php');
session_start();
session_destroy();
$sql_product = "SELECT * FROM `products`";
$show_product = mysqli_query($conn, $sql_product);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART SHOP</title>

    <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">

    <style>
        body {
            background-color: white;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: rgb(240, 123, 123);
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-family: 'Segoe UI';
            font-size: 90%;
        }


        li a:hover {
            background-color: burlywood;
        }

        h1 {
            font-size: 18px;
        }

        p {
            font-size: 16px;
        }

        div.card {
            margin: 10px;
        }

        .btn-btn-primary {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .btn-btn-primary {
        background-color: rgb(176, 255, 0);
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .btn-btn-primary:hover {
        background-color: white;
        color: rgb(176, 255, 0);
    }

    .btn-btn-primary {
        border-radius: 12px;
    }

    .input {
        width: 300px;
        height: 50px;
        padding: 10px 10px;
    }

    .search-s {
        width: 250px;
        height: 20px;
        padding: 10px 10px;
        border-radius: 20px;
        border-color: rgb(240, 123, 123);
    }

    .button {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .button {
        background-color:#FFF4C0;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .button:hover {
        background-color: white;
        color: #FFF4C0;
    }

    .button {
        border-radius: 12px;
    }
    </style>

<body>
    <ul>
        <div class="container">
            <div class="row align-items-start">
                <div class="col">
                    <li>
                        <a class="active" href="page2.php"><img src="LOGO_SM.png" width="80"></a>
                    </li>
                    <li style="float: right;">
                        <a class="account" href="login.php"><img src="user_sm.png"></a>
                    </li>
                    <li style="float: right;">
                        <a class="active" href="login.php"><img src="sell5.png" width="30"></a>
                    </li>
                    <center>
                        <input class="search-s" type="search" placeholder="Search">
                        <button class="button" style="color: rgb(240, 123, 123);">Search</button>
                    </center>
                </div>
            </div>
        </div>
    </ul>
    <center>
        <div class="container">
            <div class="row">
                <?php
                while ($data = mysqli_fetch_assoc($show_product)) {
                ?>
                    <div class="col-md-3 col-sm-6">
                        <div class="card">
                            <img src="<?php echo $data['Product_img'] ?>" width="150" height="200" class="card-img-top">
                            <div class="card-body">
                                <p class="card-text"><?php echo $data['Product_Name'] ?></p>
                                <p class="card-text">เหลือ <?php echo $data['Product_Stock'] ?> ชิ้น</p>
                                <p>
                                    <font color=red>ราคา ฿<?php echo $data['Product_Price'] ?></font>
                                </p>
                                <br>
                                <a href="login.php" class="btn-btn-primary"><img src="sell8_Edit.png" width="20"></a>
                            </div>
                        </div>
                    </div>
                <?php }

                ?>
            </div>
        </div>
    </center>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>