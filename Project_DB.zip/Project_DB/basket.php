<?php
include('server.php');
session_start();

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header('location: page2.php');
}
if (isset($_GET['Product_No'])) {
    $check = false;
    if (isset($_SESSION['Product_No'])) {
        for ($i = 0; $i < sizeof($_SESSION['Product_No']); $i++) {

            if ($_SESSION['Product_No'][$i] == $_GET['Product_No']) {
                $check = true;
                break;
            }
        }
    }
    if (!$check or !isset($_SESSION['Product_No'])) {
        $_SESSION['Product_No'][] = $_GET['Product_No'];
    }
} else if (isset($_GET['del_ID'])) {
    for ($i = 0; $i < sizeof($_SESSION['Product_No']); $i++) {

        if ($_SESSION['Product_No'][$i] == $_GET['del_ID']) {
            array_splice($_SESSION['Product_No'],$i,1);
            break;
        }
    }
}
$sql_product = "SELECT * FROM `products`";
$show_product = mysqli_query($conn, $sql_product);

$queryprd = "Select *  From Products order by Product_No ASC";

$reprd = mysqli_query($conn, $queryprd);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART SHOP</title>

    <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
</head>
<style>
    body {
        background-color: white;
    }

    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: rgb(240, 123, 123);
    }

    li {
        float: left;
    }

    li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-family: 'Segoe UI';
        font-size: 90%;
    }


    li a:hover {
        background-color: burlywood;
    }

    h1 {
        font-size: 18px;
    }

    p {
        font-size: 16px;
    }

    div.card {
        margin: 10px;
    }

    .btn-btn-primary {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .btn-btn-primary {
        background-color: rgb(176, 255, 0);
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .btn-btn-primary:hover {
        background-color: white;
        color: rgb(176, 255, 0);
    }

    .btn-btn-primary {
        border-radius: 12px;
    }

    .input {
        width: 300px;
        height: 50px;
        padding: 10px 10px;
    }

    .search-s {
        width: 250px;
        height: 20px;
        padding: 10px 10px;
        border-radius: 20px;
        border-color: rgb(240, 123, 123);
    }

    .button {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .button {
        background-color: #FFF4C0;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .button:hover {
        background-color: white;
        color: #FFF4C0;
    }

    .button {
        border-radius: 12px;
    }

    .total-price{
        float: right;
    }
    .total-price{
        background-color: #00196D;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 10px 10px;
        border-radius: 10px;
    }
</style>

<body>
    <ul>
        <div class="container">
            <div class="row align-items-start">

                <div class="col">
                    <li>
                        <a class="active" href="index.php"><img src="LOGO_SM.png" width="80"></a>
                    </li>
                    <li style="float: right;">
                        <?php if (isset($_SESSION['username'])) : ?>
                            <p>User : <strong><?php echo $_SESSION['username']; ?></strong></p>
                            <a class="btn-btn-primary" href="page2.php" style="color: red;">Logout</a>
                        <?php endif ?>
                    </li>
                    <li style="float: right;">
                        <a class="active" href="basket.php"><img src="sell5.png" width="30"></a>
                    </li>
                    <center>
                        <input class="search-s" type="search" placeholder="Search">
                        <button class="button" style="color: rgb(240, 123, 123);">Search</button>
                    </center>

                </div>
            </div>
        </div>
    </ul>
    <?php
    include('h.php');
    error_reporting(error_reporting() & ~E_NOTICE);
    ?>
    <?php
    if (isset($_SESSION['Product_No'])and sizeof($_SESSION['Product_No'])>0) {

        $total = 0;
        $query = "
SELECT * FROM products as p 
INNER JOIN type  as t ON p.product_type=t.type_id where p.Product_No in (";
        for ($i = 0; $i < sizeof($_SESSION['Product_No']); $i++) {
            $query .= "'" . $_SESSION['Product_No'][$i] . "'";
            if ($i != sizeof($_SESSION['Product_No']) - 1) {
                $query .= ",";
            }
        }
        $query .= ")";

        $result = mysqli_query($conn, $query);


        echo  ' <table class="table table-hover">';
        //หัวข้อตาราง

        echo "<tr>
      <td width=40%>Name</td>
      <td width=15%>Price</td>
      <td width=25%>type</td>
      <td width=15%>img</td>
      <td width=15%>delete</td>
    </tr>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row["Product_Name"] .  "</td> ";
            echo "<td>" . $row["Product_Price"] .  "</td> ";
            echo "<td>" . $row["type_name"] .  "</td> ";
            echo "<td align=center>" . "<img src='" . $row['Product_img'] . "' width='100'>" . "</td>";
            //ลบข้อมูล
            echo "<td><a href='basket.php?del_ID=" . $row['Product_No'] . "' onclick=\"return confirm('Do you want to delete this record? !!!')\" class='btn btn-danger btn-xs'>del</a></td> ";
            $total+= $row['Product_Price'];
            echo "</tr>";
        }
        echo "</table>";
        echo "<p class='total-price' style = 'margin-right: 40px'>Total Price $total ฿</p>";
    } else {

        echo '<center>คุณไม่ได้สั่งสิ้นค้า</center>';
    }
    //5. close connection
    mysqli_close($conn);
    ?>
    <script src="js/bootstrap.min.js"></script>
</body>