<?php
include('server.php');

$username = $_POST['username'];
$password = md5($_POST['password']);
$email = $_POST['email'];


$sql ="INSERT INTO user(username,email,password) 

    VALUES 

    ('$username','$email','$password')";
    
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);
    
    if($result){
      echo "<script>";
      echo "alert('สำเร็จ');";
      echo "window.location ='user.php'; ";
      echo "</script>";
    } else {
      
      echo "<script>";
      echo "alert('ERROR!');";
      echo "window.location ='user.php'; ";
      echo "</script>";
    }
?>