<?php
session_start();
include('server.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Login</title>
    <link rel="icon" type="image/png" href="LOGo1.png" sizes="1000x920" />
    <link rel="stylesheet" href="style.css">
</head>
<style>
    body{
        background-color: rgb(240, 123, 123);
    }
    h2 {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    p {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    label {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .button {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
    }

    .button {
        background-color: rgb(176, 255, 0);
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .button:hover {
        background-color: white;
        color: rgb(176, 255, 0);
    }

    .button {
        border-radius: 12px;
    }

    .button-two {
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .button-two {
        background-color: rgb(0,255,255);
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        -webkit-transition-duration: 0.4s;
        /* Safari */
        transition-duration: 0.4s;
        cursor: pointer;
    }

    .button-two:hover {
        background-color: white;
        color: rgb(0,255,255);
    }

    .button-two {
        border-radius: 12px;
    }
</style>

<body>

    <div class="header">
        <h2>Login</h2>
    </div>

    <form action="login_db.php" method="post">
        <?php if (isset($_SESSION['error'])) : ?>
            <div class="error">
                <h3>
                    <?php
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                </h3>
            </div>
        <?php endif ?>
        <div class="input-group">
            <label for="username">Username</label>
            <input type="text" name="username">
        </div>

        <div class="input-group">
            <label for="password">Password</label>
            <input type="password" name="password">
        </div>
        <center>
            <div class="input-group">
                <button type="submit" name="login_user" class="button">Login</button>
            </div>
            <div class="input-group">
                <a class="button-two" href="register.php">Sign Up</a>
            </div>
        </center>
    </form>

</body>

</html>