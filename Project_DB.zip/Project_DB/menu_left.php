<style>
	li {
		float: left;
	}

	li a {
		display: block;
		color: white;
		text-align: center;
		padding: 14px 16px;
		text-decoration: none;
		font-family: 'Segoe UI';
		font-size: 90%;
	}


	li a:hover {
		background-color: burlywood;
	}
</style>
<div class="list">
	<li>
		<a href="type.php" class="list">จัดการประเภทสินค้า</a>
	</li>
	<li>
		<a href="product.php" class="list-item" style="float: left;">จัดการสินค้า</a>
	</li>
	<li>
		<a href="user.php" class class="list-item" style="float: left;">จัดการผู้ใช้งาน</a>
	</li>
</div>