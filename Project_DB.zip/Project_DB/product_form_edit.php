<?php
//1. เชื่อมต่อ database:
include('server.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
$p_id = $_GET["ID"];
//2. query ข้อมูลจากตาราง:
$sql = "SELECT p.*,t.type_name
FROM Products as p 
INNER JOIN type as t ON p.Product_type= t.type_id
WHERE p.Product_No = '$p_id'
ORDER BY p.Product_No asc";
$result2 = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result2);
extract($row);

//2. query ข้อมูลจากตาราง 
$query = "SELECT * FROM type ORDER BY type_id asc";
//3.เก็บข้อมูลที่ query ออกมาไว้ในตัวแปร result .
$result = mysqli_query($conn, $query);
//4 . แสดงข้อมูลที่ query ออกมา โดยใช้ตารางในการจัดข้อมูล:
?>
<div class="container">
  <div class="row">
      <form  name="addproduct" action="product_form_edit_db.php" method="POST" enctype="multipart/form-data"  class="form-horizontal">
        <div class="form-group">
          <div class="col-sm-9">
            <p> ชื่อสินค้า</p>
            <input type="text"  name="Product_Name" class="form-control" required placeholder="ชื่อสินค้า" / value="<?php echo $Product_Name; ?>">
          </div>
        </div>
         <div class="form-group">
          <div class="col-sm-6">
            <p> ประเภทสินค้า </p>
            <select name="type_id" class="form-control" required>
              <option value="type_id">ประเภทสินค้า</option>
              <?php foreach($result as $results){?>
              <option value="<?php echo $results["type_id"];?>">
                <?php echo $results["type_name"]; ?>
              </option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-9">
            <p> ราคาสินค้า</p>
            <input type="text"  name="Product_Price" class="form-control" required placeholder="ราคา" value="<?php echo $Product_Price; ?>" >
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-9">
            <p> จำนวนสินค้า</p>
            <input type="text"  name="Product_Stock" class="form-control" required placeholder="จำนวน" value="<?php echo $Product_Stock; ?>" >
          </div>
        </div>
        <div class="form-group">
          
            <div class="form-group">
          <div class="col-sm-12">
            <p> ภาพสินค้า </p>
            <img src="<?php echo $row['Product_img'];?>" width="100px">
            <br>
            <br>
            <input type="file" name="Product_img" id="Product_img" class="form-control" />
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-12">
             <input type="hidden" name="Product_No" value="<?php echo $Product_No; ?>" />
             <input type="hidden" name="img2" value="<?php echo $Product_img; ?>" />
            <button type="submit" class="btn btn-success" name="btnadd"> บันทึก </button>
            
          </div>
        </div>
      </form>
    </div>
  </div>