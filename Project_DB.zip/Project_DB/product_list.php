<?php
//1. เชื่อมต่อ database:
include('server.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
//2. query ข้อมูลจากตาราง 
$query = "
SELECT * FROM products as p 
INNER JOIN type  as t ON p.product_type=t.type_id 
ORDER BY p.Product_No ASC";
//3.เก็บข้อมูลที่ query ออกมาไว้ในตัวแปร result .
$result = mysqli_query($conn, $query);
//4 . แสดงข้อมูลที่ query ออกมา โดยใช้ตารางในการจัดข้อมูล:

echo  ' <table class="table table-hover">';
  //หัวข้อตาราง
    echo "<tr>
      <td width='5%'>id</td>
      <td width=30%>Name</td>
      <td width=10%>Price</td>
      <td width=10%>Stock</td>
      <td width=25%>type</td>
      <td width=5%>img</td>
      <td width=5%>edit</td>
      <td width=5%>delete</td>
    </tr>";
  while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
    echo "<td>" .$row["Product_No"] .  "</td> ";
    echo "<td>" .$row["Product_Name"] .  "</td> ";
    echo "<td>" .$row["Product_Price"] .  "</td> ";
    echo "<td>" .$row["Product_Stock"] .  "</td> ";
    echo "<td>" .$row["type_name"] .  "</td> ";
    echo "<td align=center>"."<img src='".$row['Product_img']."' width='100'>"."</td>";
    //แก้ไขข้อมูล
    echo "<td><a href='product.php?act=edit&ID=$row[0]' class='btn btn-warning btn-xs'>edit</a></td> ";
    
    //ลบข้อมูล
    echo "<td><a href='product_del_db.php?ID=$row[0]' onclick=\"return confirm('Do you want to delete this record? !!!')\" class='btn btn-danger btn-xs'>del</a></td> ";
  echo "</tr>";
  }
echo "</table>";
//5. close connection
mysqli_close($conn);
?>
