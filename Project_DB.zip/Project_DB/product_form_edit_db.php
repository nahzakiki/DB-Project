<meta charset="UTF-8">
<?php
//1. เชื่อมต่อ database: 
include('server.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');

//สร้างตัวแปรสำหรับรับค่าที่นำมาแก้ไขจากฟอร์ม
$Product_No = $_POST['Product_No'];
$Product_Name = $_POST['Product_Name'];
$Product_type = $_POST['type_id'];
$Product_Price = $_POST['Product_Price'];
$Product_Stock = $_POST['Product_Stock'];
$p_img = (isset($_POST['Product_img']) ? $_POST['Product_img'] : '');
$img2 = $_POST['img2'];
$upload = $_FILES['Product_img']['name'];
if ($upload != '') {

    //ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname =  $_FILES['Product_img']['name'];
	$path_copy = $newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['Product_img']['tmp_name'], $path_copy);
} else {
    $newname = $img2;
}

//ทำการปรับปรุงข้อมูลที่จะแก้ไขลงใน database 

$sql = "UPDATE Products SET  
			Product_Name='$Product_Name',
			Product_Price='$Product_Price',
            Product_Stock='$Product_Stock',
		    Product_img='$newname',
            Product_type='$Product_type' 
			WHERE Product_No='$Product_No' ";

//echo $Product_No.'<br>'.$Product_Name.'<br>'.$Product_type.'<br>'.$Product_Price.'<br>'.$Product_Stock.'<br>'.$newname;
$result = mysqli_query($conn, $sql);

mysqli_close($conn); //ปิดการเชื่อมต่อ database 

//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม

if ($result) {
    echo "<script type='text/javascript'>";
    echo "alert('Update Succesfuly');";
    echo "window.location = 'product.php'; ";
    echo "</script>";
} else {
    echo "<script type='text/javascript'>";
    echo "alert('Error back to Update again');";
    echo "</script>";
}
?>
