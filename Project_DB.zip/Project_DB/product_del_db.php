<meta charset="UTF_8">
<?php
    include('server.php');

    $Product_No = $_REQUEST["ID"];

    $sql = "DELETE FROM Products where Product_No = '$Product_No' ";
    $result = mysqli_query($conn,$sql);

    if($result){
        echo "<script type='text/javascript'>";
        echo "window.location = 'product.php'; ";
        echo "</script>";
    }
    else{
        echo "<script type= 'text/javascript'>";
        echo "alert('Error back to delete again'); ";
        echo "</script>";
    }
?>