<?php
include('server.php');

$type_name = $_POST['type_name'];
$qty = "select type_id from type";
$result2 = $conn->query($qty);
$type_id = "";
while($row = mysqli_fetch_array($result2)){
  $type_id = $row['type_id'] ;
} 
$type_id = ((int)$type_id)+1;
$sql ="INSERT INTO type(type_id,type_name) 

    VALUES 

    ('$type_id','$type_name')";
    
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);
    
    if($result){
      echo "<script>";
      echo "alert('สำเร็จ');";
      echo "window.location ='type.php'; ";
      echo "</script>";
    } else {
      
      echo "<script>";
      echo "alert('ERROR!');";
      echo "window.location ='type.php'; ";
      echo "</script>";
    }
?>